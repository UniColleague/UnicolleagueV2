package com.swe444.demo.service;

import com.swe444.demo.entity.Role;

public interface RoleService {

    void save(Role role);
}
