package com.swe444.demo.service;



import com.swe444.demo.entity.User;

import java.util.List;

public interface UserService {


    User findUserByUsername(String name);

    List<User> searchForUserByUsername(String name);



    List<User> findAllUsers();

    void save(User user);

    void update(User user);
}
