package com.swe444.demo.controller;

import com.swe444.demo.entity.Role;
import com.swe444.demo.entity.User;
import com.swe444.demo.service.RoleService;
import com.swe444.demo.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/main")
public class MainController {

    UserService userService;

    RoleService roleService;

    @Autowired
    public MainController(UserService userService, RoleService roleService){
        this.userService = userService;
        this.roleService = roleService;
    }

    @RequestMapping(value = "/username", method = RequestMethod.GET)
    @ResponseBody
    public String getName(HttpServletRequest request){
        Principal principal = request.getUserPrincipal();
        return principal.getName();
    }

    @GetMapping("/showRegisterForm")
    public String showRegisterForm(Model theModel){

        theModel.addAttribute("newUser", new User());

        return "register-form";
    }

    @GetMapping("/recoverPassword")
    public String recoverPassword(Model theModel){

        theModel.addAttribute("user", new User());

        return "recover-password";
    }

    @PostMapping("/updatePassword")
    public String updatePassword(@ModelAttribute("user") User user){
        System.out.println(user.getPassword());
        System.out.println(user.getConfirmPassword() + "??");
        return "redirect:/showLoginForm";
    }

    @PostMapping("/saveUser")
    public String saveUser(@ModelAttribute("newUser") User user){


        User theUser = new User(user.getUsername(),"{noop}"+user.getPassword(),1,user.getEmail());
        System.out.println("It works!");
        theUser.setImage("https://cdn.analyticsvidhya.com/wp-content/uploads/2023/04/ai-generated-gba2dce9e3_1920_xMPNobD.jpg");
        userService.save(theUser);
        Role role = new Role( "ROLE_USER",user.getUsername());
        theUser.addRole(role);
        roleService.save(role);
        userService.save(theUser);

        return "redirect:/showLoginForm";
    }

    @GetMapping("/home")
    public String homePage(){

        return "main-page";
    }

    @GetMapping("/profile")
    public String showProfile(Model theModel, HttpServletRequest request){
        User user = userService.findUserByUsername(getName(request));

        theModel.addAttribute("user", user);

        return "profile";
    }
    @GetMapping("/showEditForm")

    public String showEditForm(Model theModel, HttpServletRequest request){
        User theUser = userService.findUserByUsername(getName(request));

        String newPass = "";
        char[] pass = new char[theUser.getPassword().length()];
        int j =0;
        for(int i = 6; i < theUser.getPassword().length(); i++){
            pass[j++] = theUser.getPassword().charAt(i);
            newPass += pass [j-1];
        }
        System.out.println(newPass);
        theUser.setPassword(newPass);
        theModel.addAttribute("currentUser", theUser);

        return "edit-account";
    }

    @PostMapping("/updateUser")
    public String updateUser(@ModelAttribute("currentUser") User user){
        User theUser = userService.findUserByUsername(user.getUsername());
        if(!user.getImage().equals("")) {
            theUser.setImage(user.getImage());
        }
        theUser.setEmail(user.getEmail());
        theUser.setPassword("{noop}" + user.getPassword());


        userService.save(theUser);

        return "redirect:/main/profile";
    }




}
